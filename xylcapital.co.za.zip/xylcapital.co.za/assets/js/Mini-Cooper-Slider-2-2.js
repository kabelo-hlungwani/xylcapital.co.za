$(document).ready(function() {

			
			$('#slider').layerSlider({
				sliderVersion: '6.0.0',
				type: 'fullsize',
				responsiveUnder: 0,
				maxRatio: 1,
				hideUnder: 0,
				hideOver: 100000,
				skin: 'outline',
				sliderFadeInDuration: 800,
				tnContainerWidth: '100%',
				tnWidth: 170,
				tnHeight: 100,
				skinsPath: '../../layerslider/skins/',
				height: 600
			});
		});
